# RISUL-AN-AI-BOT
An ai bot to make things easier
## What can this bot do?
<ul>
  <li>Open the following app
    <ul>
      <li>Notepad</li>
      <li>Spotify</li>
      <li>Whatsapp</li>
      <li>MS word</li>
      <li>Netflix</li>
      <li>File explorer</li>
      <li>Calculater</li>
      <li>Camera</li>
      <li>Vlc</li>
      <li>Chrome</li>
    </ul>
  </li>
  <li>Play something on youtube</li>
  <li>Search something on google</li>
  <li>Tell you a joke</li>
  <li>Give you an advice</li>
  <li>Send someone a message through whatsapp</li>
  <li>Send an email to someone</li>
  </ul>
  
## How can you use this bot?
  The very first thing you would need is python itself,<br>
  Then you would need to go to your command prompt and install the following modules(Just copy and paste them)
  <ul>
    <li>pip install pyttsx3</li>
    <li>pip install speech_recognition</li>
    <li>pip install datetime</li>
    <li>pip install pywhatkit</li>
    <li>pip install AppOpener</li> 
    <li>pip install time</li>
    <li>pip install requests</li>
    <li>pip install smtplib</li>
  </ul>
  Now download the file
  <a href="https://github.com/Vishistt/RISUL-AN-AI-BOT/archive/refs/heads/main.zip">By clicking here</a>
  <br>
  Done now Enjoy:)

  
  
  
      
  
